#include <stdio.h>
#include "pico/stdlib.h"
#include "hardware/gpio.h"

// Definições de pinos
#define LED_PIN_VD 13
#define LED_PIN_VM 12
#define LED_PIN_AZ 11
#define BUTTON_PIN_A 5
#define BUTTON_PIN_B 6
#define FREQ_INPUT_PIN 16

// Configurações de tempo
#define DEBOUNCE_DELAY_MS 50
#define PISCA_LED_FREQ 10
#define PISCA_DURACAO 10

volatile uint64_t previous_time = 0;
volatile uint64_t current_period = 0;

// Interrupção para medição de frequência
void gpio_callback(uint gpio, uint32_t events) {
    uint64_t current_time = time_us_64();
    if (previous_time != 0) {
        current_period = current_time - previous_time;
    }
    previous_time = current_time;
}

// Função para piscar LED na frequência definida
void freq_pisca_led() {
    uint32_t periodo_ms = 1000 / PISCA_LED_FREQ;
    uint32_t total_ciclos = PISCA_DURACAO * PISCA_LED_FREQ;
    for (uint32_t i = 0; i < total_ciclos; i++) {
        gpio_put(LED_PIN_AZ, 1);
        sleep_ms(periodo_ms / 2);
        gpio_put(LED_PIN_AZ, 0);
        sleep_ms(periodo_ms / 2);
    }
}

// Leitura de botão com debounce
bool read_botao(uint gpio_button) {
    static bool last_state = false;
    bool current_state = gpio_get(gpio_button);
    if (current_state && !last_state) {
        sleep_ms(DEBOUNCE_DELAY_MS);
        if (gpio_get(gpio_button)) {
            last_state = true;
            return true;
        }
    } else if (!current_state) {
        last_state = false;
    }
    return false;
}

// Inicialização dos pinos de entrada e saída
void setup_gpio() {
    gpio_init(FREQ_INPUT_PIN);
    gpio_set_dir(FREQ_INPUT_PIN, GPIO_IN);
    gpio_pull_up(FREQ_INPUT_PIN);
    
    gpio_init(LED_PIN_VM);
    gpio_set_dir(LED_PIN_VM, GPIO_OUT);
    gpio_init(LED_PIN_VD);
    gpio_set_dir(LED_PIN_VD, GPIO_OUT);
    gpio_init(LED_PIN_AZ);
    gpio_set_dir(LED_PIN_AZ, GPIO_OUT);
    
    gpio_init(BUTTON_PIN_A);
    gpio_set_dir(BUTTON_PIN_A, GPIO_IN);
    gpio_pull_down(BUTTON_PIN_A);
    
    gpio_init(BUTTON_PIN_B);
    gpio_set_dir(BUTTON_PIN_B, GPIO_IN);
    gpio_pull_down(BUTTON_PIN_B);
    
    gpio_set_irq_enabled_with_callback(FREQ_INPUT_PIN, GPIO_IRQ_EDGE_RISE, true, &gpio_callback);
}

int main() {
    stdio_init_all();
    setup_gpio();
    
    int button_press_count = 0;
    bool button_was_pressed = false;

    while (true) {
        if (gpio_get(BUTTON_PIN_A)) {
            gpio_put(LED_PIN_AZ, 1);
            gpio_put(LED_PIN_VM, 0);
            gpio_put(LED_PIN_VD, 0);
        } else if (gpio_get(BUTTON_PIN_B)) {
            gpio_put(LED_PIN_AZ, 0);
            gpio_put(LED_PIN_VM, 1);
            gpio_put(LED_PIN_VD, 0);
        } else {
            gpio_put(LED_PIN_AZ, 0);
            gpio_put(LED_PIN_VM, 0);
            gpio_put(LED_PIN_VD, 1);
        }
        
        bool button_is_pressed = gpio_get(BUTTON_PIN_A);
        if (button_is_pressed && !button_was_pressed) {
            sleep_ms(DEBOUNCE_DELAY_MS);
            if (gpio_get(BUTTON_PIN_A)) {
                button_press_count++;
                printf("Botão pressionado %d vezes\n", button_press_count);
                
                if (button_press_count >= 5) {
                    freq_pisca_led();
                    if (current_period != 0) {
                        float frequency = 1000000.0f / (float)current_period;
                        printf("Frequência: %.2f Hz\n", frequency);
                    }
                    button_press_count = 0;
                }
            }
        }
        button_was_pressed = button_is_pressed;
    }
    return 0;
}
