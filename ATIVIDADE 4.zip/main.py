//Camilly Duarte
from machine import Pin

led = Pin(3, Pin.OUT)
pul = Pin(4, Pin.IN)

while True:
    if pul.value()==1:
        led.value(1)
        else:
            led.value(0)